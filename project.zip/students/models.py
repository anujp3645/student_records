from django.db import models

# Create your models here.
class student(models.Model):
    name=models.CharField(max_length=30,null=True)
    email=models.CharField(max_length=30,null=True)
    college=models.CharField(max_length=30,null=True)
    city=models.CharField(max_length=30,null=True)
    jdate=models.CharField(max_length=30,null=True)
    totalf=models.CharField(max_length=30,null=True)
    paidf=models.CharField(max_length=30,null=True)
    leftf=models.CharField(max_length=30,null=True)
    phone=models.CharField(max_length=30,null=True)
    technology=models.CharField(max_length=30,null=True)
    image=models.FileField(null=True)

    